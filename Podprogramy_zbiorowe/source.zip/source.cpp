//Mateusz Paszyński
#include <iostream>
using namespace std;
void sortuj ( int tab[], int rozmiar)
{
    int i = rozmiar, j, pomocnik;
    while ( i-- )
    {
        j = rozmiar - 1 ;
        while ( j-- )
        {
            if ( tab [ j ] > tab [ j + 1 ] )
            {
                pomocnik = tab [ j ];
                tab [ j ] = tab [ j + 1 ];
                tab [ j + 1 ] = pomocnik;

            }
        }
    }
}
void Cardinality ( int tab[],int *power)
{
    *power = 0;
    int i = 0;
    while ( tab[i] != -1)
    {
        *power = *power + 1;
        i++;
    }

}
int Cardinality2( int tab[])
{
    int power = 0;
    int i = 0;
    while ( tab[i] != -1)
    {
        power = power + 1;
        i++;
    }
return power;
}

bool Element ( int szukana, int tab[]  )
{
    int i = 0;
    while ( tab [ i ] != -1)
    {

        if ( tab [ i ] == szukana )
        {

            return 1;
        }
        i++;
    }
    return 0;
}
bool Subset ( int tab1[], int tab2[])
{

    bool czy;
    int i = 0;
    while ( tab1 [ i ]!= -1)
    {
        czy = Element(tab1[i],tab2);

            if ( czy == 0)
            {
                return 0;
            }

        i++;
    }
    return 1;
}
bool Equal ( int tab1[], int tab2[])
{

    if ( Cardinality2(tab1) != Cardinality2(tab2))
    {
        return 0;
    }
    bool czy;
    int i = 0;
    while ( tab1 [ i ]!= -1)
    {
        czy = Element(tab1[i],tab2);

            if ( czy == 0)
            {
                return 0;
            }

        i++;
    }
    return 1;
}
bool Empty ( int tab[])
{
    if ( tab [ 0 ] == -1)
    {
        return 1;
    }
    return 0;
}
bool Nonempty ( int tab[] )
{
    if ( tab [ 0 ] == -1)
    {
        return 0;
    }
    else return 1;
}
double Arithmetic (int tab[])
{
    int i = 0;
    double avg = 0;
    while( tab [ i ] != -1)
    {
        avg += tab[i];
        i++;
    }
    if ( i == 0)
    {
        avg = 0;
        i = 1;
    }
    avg /= i;
    return avg;
}
double Harmonic (int tab[])
{
    int i = 0;
    float har = 0;
    float part;

    while ( tab [ i ] != -1)
    {
        float part = ( 1.00 / tab [ i ]);

        har += part;
        i++;


    }
    har = (float ( i ) / har );

    if ( i == 0)
    {
        har = 1;
        i = 1;
        har /= i;
    }

    return har;
}
void Add(int x, int tab[])
{
    int flaga = 0;
    if (( x > 0 ) && (x < 4096))
    {
        int i = 0;
        while( tab [ i ] != -1 )
        {
            if ( tab [ i ] == x )
            {
                flaga = 1;
            }
            i++;
        }
        if ( flaga == 0)
        {
            tab [ i ] = x;
            sortuj( tab, i + 1 );
            tab [ i + 1 ] = -1;
        }



    }
}
void Create (int x, int tab1[], int tab2[])
{
    int i = 0;
    sortuj (tab1,x);

    while ( x-- )
    {
        if ((tab1 [ x ] > 0 ) && ( tab1 [ x ] < 4096) )

        {
            if ( ( i == 0 )||  (tab1 [ x + 1 ] != tab1 [ x ]))
            {

                tab2 [ i ] = tab1 [ x ];
                i++;
            }

        }

    }
    sortuj (tab2,i);
    tab2 [ i  ] = -1;
}
void Union ( int tab1[], int tab2[],int tab[])
{
    int i = 0;
    int x = 0;
    while ( tab1 [ i ] != -1)
    {
        tab [ i ] = tab1 [ i ];
        i++;
    }
    tab[ i ] = -1;
    while ( tab2 [ x ] != -1)
    {
        bool czy = Element (tab2 [ x ],tab);

        if ( czy == 0 )
        {

            Add(tab2[x],tab);
        }

        x++;
    }

}
void Intersection ( int  tab1[], int tab2[], int tab3[])
{
    int i = 0;
    int rozmiar1 = 0,rozmiar2 = 0;

    while (tab1 [ i ] != -1)
    {
        rozmiar1++;
        i++;
    }
    i  = 0;
    while(tab2 [i] != -1)
    {
        rozmiar2++;
        i++;
    }
    i = 0;
    int x = 0;
    bool czy;
    if ( rozmiar1 <= rozmiar2)
    {
        while( tab2[ i ] != -1)
        {

            czy = Element(tab2[ i ],tab1);

            if( czy == 1 )
            {
               tab3 [ x ] = tab2[i];
               x++;
            }
            i++;
        }
    }

    else
    {
        i = 0;
        x = 0;
        while(tab1[ i ] != -1)
        {
            //cout<<"tab1["<<i<<"] = "<<tab1[i]<<char(32);
            czy = Element(tab1[ i ],tab2);
            //cout<<" czy = " <<czy<<" ";
            //cout<<endl;
            if( czy == 1 )
            {
                tab3 [ x ] = tab1 [ i ];

                x++;
            }
            i++;
        }
    }
    tab3 [ x ] = -1;

i = 0;

    sortuj(tab3,x);


}
void Difference (int  tab1[], int tab2[], int tab3[])
{
    int i = 0;
    bool czy;
    int x = 0;
    while( tab1[ i ]!= -1)
    {
        czy = Element(tab1[i],tab2);
        if (czy == 0 )
        {
            tab3[x] = tab1 [ i ];
            x++;
        }
        i++;
    }
    tab3 [ x ] = -1;
    sortuj(tab3,x);
}
void Symmetric (int  tab1[], int  tab2[], int tab3[])
{
    int i = 0;
    int x = 0;
    bool czy;
    while( tab1[ i ]!= -1)
    {
        czy = Element(tab1[i],tab2);
        if (czy == 0 )
        {
            tab3[x] = tab1[i];
            x++;
        }

        i++;
    }
    i = 0;
    while( tab2 [ i ] != -1)
    {
        czy = Element(tab2[i],tab1);
        if (czy == 0 )
        {
            tab3[x] = tab2[i];
            x++;
        }

        i++;
    }
    tab3 [ x ] = -1;
    sortuj(tab3,x);
}
void MinMax ( int tab[],int* Minn,int& Maxx)
{
    if ( tab[0]!=-1)
    {
        *Minn = tab[0];
        Maxx = tab[0];
        int i = 1;
        while ( tab[ i ]!= -1)
        {
            if ( tab [ i ] > Maxx)
            {
                Maxx = tab [ i ];
            }
            if ( tab [ i ] < *Minn)
            {
                *Minn = tab [ i ];
            }
            i++;
        }
    }
}

void Complement (int tab1[],int tab[])
{

    int i = 1;
    int  x = 0;
    bool czy;
    while ( i < 4096)
    {
        czy = Element(i,tab1);
        if ( czy == 0)
        {
            tab [ x ] = i ;
            x++;
        }
        i++;
    }
    tab [ x ] = -1;

}
void Properties  (int tab[],char* n,double & srednia,double * har, int & minn,int * maxx,int & moc)
{
    int i = 0;
    while((i+1))
    {
        if ( n[ i ] == 'a')
        {
            srednia = Arithmetic(tab);
        }
        else if ( n [ i ] == 'h' )
        {
            * har = Harmonic(tab);
        }
        else if ( n [ i ]== 'm' )
        {

            MinMax(tab,&minn,*maxx);
        }
        else if ( n [ i ] == 'c')
        {
            Cardinality(tab,&moc);
        }
        else { i = -2;}
        i++;
    }

}
/*int main()
{

    int zbior2[] = {-1};
    int zbior1[] = {1,2,3,4,-1};
    int tab[4096]={-1};

    Complement(zbior2,tab);


    int i = 0;
    while(tab[ i ] != -1)
    {
        cout<<tab[i]<<endl;
        i++;
    }

    return 0;
}*/

